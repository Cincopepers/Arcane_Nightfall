// Arcane Nightfall - Game server (Node + ws)
const http = require('http');
const WebSocket = require('ws');
const uuid = require('uuid').v4;
const server = http.createServer();
const wss = new WebSocket.Server({ server });
const PORT = process.env.PORT || 3001;
const SESSIONS = {}; // sessionId -> {players: {id:ws}, battle}
const SLOTS = require('./data/slots.json');
const SPELLS = require('./data/spells.json');

function createBattleForPlayers(playerList){
  const avgLevel = Math.max(1, Math.floor(playerList.reduce((s,p)=>s+1,0)/Math.max(1,playerList.length)));
  const enemy = { id:'enemy_abyss', name:'Umbra Warden', hp:120 + avgLevel*12, maxHp:120 + avgLevel*12, ac:12 + Math.floor(avgLevel/2), sprite:'enemy_idle' };
  const players = playerList.map((p,i)=>({ id:p.id, name:p.name, hp:60 + i*6, maxHp:60 + i*6, level:1, sprite:'hero_idle_'+i, used_specials:[] }));
  return { id: uuid(), enemy, players, turnIndex:0, log:[], guildId: null };
}

function broadcast(session, msg){
  for(const pid in session.players){
    const ws = session.players[pid];
    if(ws && ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(msg));
  }
}

function rollDice(notation){
  let parts = notation.split('+');
  let dice = parts[0];
  let add = parts.length>1? parseInt(parts[1]):0;
  const [cnt,die] = dice.split('d').map(Number);
  let s=0; for(let i=0;i<cnt;i++) s += 1 + Math.floor(Math.random()*die);
  return s + add;
}

function resolveSpell(battle, casterId, spellKey, targetIds){
  const spell = SPELLS[spellKey];
  if(!spell) return { error:'Unknown spell' };
  const caster = battle.players.find(p=>p.id===casterId);
  const log = [];
  if(spell.target === 'aoe'){
    const saveDC = 10 + Math.floor((caster.level||1)/2) + 2;
    const enemy = battle.enemy;
    const dmg = rollDice(spell.damage);
    const save = 1 + Math.floor(Math.random()*20);
    const half = save >= saveDC;
    const applied = half? Math.floor(dmg/2): dmg;
    enemy.hp = Math.max(0, enemy.hp - applied);
    log.push(caster.name + ' casts ' + spell.name + ' -> ' + applied + ' ' + spell.type + ' damage' + (half? ' (half)': ''));
  } else if(spell.target === 'single'){
    const dmg = rollDice(spell.damage);
    battle.enemy.hp = Math.max(0, battle.enemy.hp - dmg);
    log.push(caster.name + ' casts ' + spell.name + ' on ' + battle.enemy.name + ' -> ' + dmg + ' ' + spell.type + ' damage');
  } else if(spell.target === 'heal'){
    const pid = targetIds && targetIds.length? targetIds[0]: casterId;
    const p = battle.players.find(x=>x.id===pid) || caster;
    const heal = rollDice(spell.heal);
    p.hp = Math.min(p.maxHp, (p.hp||0) + heal);
    log.push(caster.name + ' casts ' + spell.name + ', healing ' + p.name + ' for ' + heal);
  }
  return { log };
}

wss.on('connection', (ws)=>{
  ws.id = uuid();
  ws.on('message', (msg)=>{
    let data; try { data = JSON.parse(msg); } catch(e){ return; }
    if(data.type === 'create_session'){
      const sid = uuid(); SESSIONS[sid] = { players: {}, battle: null };
      SESSIONS[sid].players[ws.id] = ws;
      ws.send(JSON.stringify({ type:'session_created', sessionId:sid, yourId:ws.id }));
    } else if(data.type === 'join_session'){
      const sid = data.sessionId; const session = SESSIONS[sid];
      if(!session){ ws.send(JSON.stringify({ type:'error', message:'session not found' })); return; }
      session.players[ws.id] = ws;
      ws.send(JSON.stringify({ type:'joined', sessionId:sid, yourId:ws.id }));
      broadcast(session, { type:'player_joined', id: ws.id });
    } else if(data.type === 'start_battle'){
      const sid = data.sessionId; const session = SESSIONS[sid]; if(!session) return;
      const pl = Object.keys(session.players).map((pid,idx)=>({ id: pid, name: 'Hero' + (idx+1) }));
      session.battle = createBattleForPlayers(pl);
      session.battle.guildId = data.guildId || null;
      broadcast(session, { type:'battle_started', battle: session.battle });
    } else if(data.type === 'action'){
      const sid = data.sessionId; const session = SESSIONS[sid]; if(!session || !session.battle) return;
      const payload = data.payload;
      if(payload.action === 'attack'){
        const battle = session.battle;
        const actor = battle.players.find(p=>p.id===payload.actorId);
        if(!actor) return;
        const roll = 1 + Math.floor(Math.random()*20);
        const dmg = 1 + Math.floor(Math.random()*8) + Math.floor((actor.level||1)/2);
        const hit = (roll + 2) >= battle.enemy.ac || roll === 20;
        const total = hit ? dmg : 0;
        battle.enemy.hp = Math.max(0, battle.enemy.hp - total);
        const entry = actor.name + ' attacks (' + roll + ') -> ' + (hit? total + ' dmg':'miss');
        battle.log.push(entry);
        broadcast(session, { type:'action_resolved', result:{ total, hit, roll, actorId: actor.id }, battle: session.battle });
        if(battle.enemy.hp <= 0){ broadcast(session, { type:'battle_end', battle: session.battle, reward:{ xp: 75 } }); }
      } else if(payload.action === 'cast'){
        const battle = session.battle;
        const res = resolveSpell(battle, payload.actorId, payload.spellKey, payload.targets || []);
        if(res.error){ ws.send(JSON.stringify({ type:'error', message: res.error })); return; }
        battle.log.push(...res.log);
        broadcast(session, { type:'action_resolved', result:res, battle: session.battle });
        if(battle.enemy.hp <= 0){ broadcast(session, { type:'battle_end', battle: session.battle, reward:{ xp: 100 } }); }
      }
    }
  });
  ws.on('close', ()=>{ for(const sid in SESSIONS){ const s = SESSIONS[sid]; if(s.players[ws.id]){ delete s.players[ws.id]; broadcast(s, { type:'player_left', id: ws.id }); } } });
});

server.listen(PORT, ()=>console.log('Arcane Nightfall server listening on', PORT));

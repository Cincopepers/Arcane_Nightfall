# Arcane Nightfall - Bot launcher (sample)
# Posts a session link and code. Replace placeholders and run with your bot token.
import os
import random
import discord
from discord.ext import commands
from dotenv import load_dotenv
load_dotenv()
TOKEN = os.getenv('DISCORD_TOKEN')
ACTIVITY_URL = os.getenv('ACTIVITY_URL','https://yourgame.example/session/')
bot = commands.Bot(command_prefix='!')
@bot.event
async def on_ready():
    print('Bot ready')
@bot.command()
async def startarcane(ctx):
    code = str(random.randint(100000,999999))
    url = ACTIVITY_URL + code
    await ctx.send(f'Arcane Nightfall session: {url} (code {code})')
    await ctx.send('Join the activity to play!')

if __name__=='__main__':
    bot.run(TOKEN)
